# Food Ordering Interface — Basil & Bone

A modern, responsive food ordering UI built with plain HTML, CSS, and JavaScript. Users can browse menu items by category, add them to a cart, and see a running order total — all client-side, no backend required.

**Live Demo:** [Add your GitHub Pages link here]
**Video Demo:** [Add your 60-second demo link here]

## Preview

![Food ordering interface preview](preview.png)

## Features

- Restaurant banner with branding and hours
- Category filter (Pizza, Burgers, Sides, Drinks, or All)
- Food cards with image/emoji, name, price, and description
- **Add to Cart** button with instant visual confirmation
- Slide-in cart panel with:
  - Quantity increment/decrement per item
  - Live subtotal, delivery fee, and total
  - Empty-state messaging
- Sticky cart bar that appears once an item is added
- Fully responsive grid layout (mobile, tablet, desktop)
- Hover and press animations on cards and buttons

## Tech Stack

- HTML5
- CSS3 (Flexbox, Grid, custom properties, transitions)
- Vanilla JavaScript (cart state, DOM rendering, event handling)
- Google Fonts (Fraunces, Inter)

## Project Structure

```
food-ordering-app/
├── index.html
├── preview.png        (screenshot for this README)
└── README.md
```

> This project is a single self-contained `index.html` file with inline CSS/JS and an in-memory JavaScript menu object — no build step or dependencies needed.

## Getting Started

1. Clone the repo:
   ```bash
   git clone https://github.com/<your-username>/food-ordering-app.git
   ```
2. Open `index.html` directly in your browser.

## How It Works

- The menu is stored as a JavaScript object (`MENU`), grouped by category.
- Clicking a category button filters which sections are shown.
- Clicking **Add** updates a `cart` object keyed by item ID and re-renders the cart panel, totals, and cart bar.
- Quantity buttons in the cart update or remove items in real time.
- **Place order** clears the cart and confirms the order (placeholder alert — swap in a real checkout flow if extending this project).

## Deployment

Deployed with **GitHub Pages**:
1. Push the repo to GitHub.
2. Go to **Settings → Pages**.
3. Set source to the `main` branch, root folder.
4. Your site will be live at `https://<your-username>.github.io/food-ordering-app`.

## What I Learned

- Managing UI state (a shopping cart) with vanilla JavaScript
- Rendering dynamic lists from data instead of hardcoding HTML
- Building a slide-in panel and sticky bar with CSS transitions
- Structuring a responsive card grid for varying screen sizes

## Author

**Abigail Zandra V**
- Email: abigail.zandrav@example.com
- GitHub: [github.com/abigailzandrav](https://github.com/abigailzandrav)
- LinkedIn: [linkedin.com/in/abigailzandrav](https://linkedin.com/in/abigailzandrav)
